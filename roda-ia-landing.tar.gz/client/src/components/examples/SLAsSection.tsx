import { SLAsSection } from "../SLAsSection";

export default function SLAsSectionExample() {
  return <SLAsSection />;
}
