import { Deliverables } from "../Deliverables";

export default function DeliverablesExample() {
  return <Deliverables />;
}
