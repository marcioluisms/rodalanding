import { ToolsSection } from "../ToolsSection";

export default function ToolsSectionExample() {
  return <ToolsSection />;
}
