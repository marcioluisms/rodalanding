import { HowWeWork } from "../HowWeWork";

export default function HowWeWorkExample() {
  return <HowWeWork />;
}
