import { PrivacySection } from "../PrivacySection";

export default function PrivacySectionExample() {
  return <PrivacySection />;
}
