import { ValueBullets } from "../ValueBullets";

export default function ValueBulletsExample() {
  return <ValueBullets />;
}
