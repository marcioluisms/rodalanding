import { FinalCTA } from "../FinalCTA";

export default function FinalCTAExample() {
  return <FinalCTA />;
}
